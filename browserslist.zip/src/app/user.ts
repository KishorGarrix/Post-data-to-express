export class User {
    constructor(
        public name:string,
        public email:string,
        public password:string,
        public phone:number,
        public city:string,
        public gender:string,
       /*  public subscribe:boolean */
    ){}

    }
    