import { Component } from '@angular/core';
import { User } from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
 city=["Bangalore","Mumbai","pune"];
 userModel=new User('','kishor@gmail.com','',986565666,'Bangalore','male');  
 onSubmit(){
   console.log(this.userModel);
 }
}
